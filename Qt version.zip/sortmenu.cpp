#include "sortmenu.h"
#include "ui_sortmenu.h"
#include "Windows.h"
#include <QMessageBox>

#include "Functions.h"

SortMenu::SortMenu(QWidget *parent, Sequence<int>* Seq) :
    QDialog(parent),
    ui(new Ui::SortMenu)
{
    seq = Seq;
    ui->setupUi(this);
}

SortMenu::~SortMenu()
{
    delete ui;
}

void SortMenu::on_backButton4_clicked()
{
    close();
    exit(0);
}

void SortMenu::on_bubbleButton_clicked()
{
    ui->statusLabel->setText("");
    hide();
    sort = new Sort(this, seq, "Bubble Sort");
    sort->show();
}

void SortMenu::on_insertButton_clicked()
{
    ui->statusLabel->setText("");
    hide();
    sort = new Sort(this, seq, "Insetrion Sort");
    sort->show();
}

void SortMenu::on_selectButton_clicked()
{
    ui->statusLabel->setText("");
    hide();
    sort = new Sort(this, seq, "Selection Sort");
    sort->show();
}

void SortMenu::on_shellButton_clicked()
{
    ui->statusLabel->setText("");
    hide();
    sort = new Sort(this, seq, "Shell Sort");
    sort->show();
}

void SortMenu::on_quickButton_clicked()
{
    ui->statusLabel->setText("");
    hide();
    sort = new Sort(this, seq, "Quick Sort");
    sort->show();
}

void SortMenu::on_shuffleButton_clicked()
{
    shuffle(seq);
    QString shuf = "Shuffled!";
    ui->statusLabel->setText(shuf);
}
