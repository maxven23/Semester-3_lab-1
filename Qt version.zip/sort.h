#ifndef SORT_H
#define SORT_H

#include <QDialog>
#include "FullCode.h"
#include "Functions.h"

namespace Ui {
class Sort;
}

class Sort : public QDialog
{
    Q_OBJECT

public:
    explicit Sort(QWidget *parent = nullptr, Sequence<int>* Seq = nullptr, QString STYPE = "");
    ~Sort();

private slots:
    void on_backButtonSort_clicked();

    void on_ascButton_clicked();

    void on_descButton_clicked();

private:
    QString SortType;
    Sequence<int>* seq;
    Ui::Sort *ui;
};

#endif // SORT_H
