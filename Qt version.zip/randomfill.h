#ifndef RANDOMFILL_H
#define RANDOMFILL_H

#include <QDialog>
#include "FullCode.h"

namespace Ui {
class RandomFill;
}

class RandomFill : public QDialog
{
    Q_OBJECT

public:
    explicit RandomFill(QWidget *parent = nullptr, int SIZE = 1, QString TYPE = "Array", Sequence<int>* Seq = nullptr);
    ~RandomFill();

private:
    int Size;
    QString Type;
    Sequence<int>* seq;
    Ui::RandomFill *ui;
};

#endif // RANDOMFILL_H
