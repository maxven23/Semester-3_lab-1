#ifndef SIZEMENU_H
#define SIZEMENU_H

#include <QDialog>
#include "typemenu.h"

namespace Ui {
class SizeMenu;
}

class SizeMenu : public QDialog
{
    Q_OBJECT

public:
    explicit SizeMenu(QWidget *parent = nullptr);
    ~SizeMenu();

private slots:
    void on_pushButton_2_clicked();

    void on_confirmBurron1_clicked();

private:
    Ui::SizeMenu *ui;
    TypeMenu *typeMenu;
};

#endif // SIZEMENU_H
