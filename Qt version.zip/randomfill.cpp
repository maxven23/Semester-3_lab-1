#include "randomfill.h"
#include "ui_randomfill.h"

RandomFill::RandomFill(QWidget *parent, int SIZE, QString TYPE, Sequence<int>* Seq) :
    QDialog(parent),
    ui(new Ui::RandomFill)
{
    Size = SIZE;
    Type = TYPE;
    seq = Seq;
    if (Type == "Array") {
        for (int i = 0; i < Size; i++) {
            seq->Set(i, i);
        }
    }
    else if (Type == "List") {
        for (int i = 0; i < Size; i++) {
            seq->Prepend(i);
        }
    }
    ui->setupUi(this);
}

RandomFill::~RandomFill()
{
    delete ui;
}
