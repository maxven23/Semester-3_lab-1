#pragma once
#include <iostream>
#include <ctime>
#include <chrono>
#include <stdio.h>

using namespace std;

template <class T>

class Sequence
{
public:
    virtual Sequence<T>* GetSubSequence(int start, int end) = 0;
    virtual Sequence<T>* Copy() = 0;
	virtual Sequence<T>* Concat(Sequence<T>* toConcat) = 0;

	virtual int GetSize() const = 0;
	virtual T Get(int index) const = 0;
	virtual T GetLast() const = 0;
	virtual T GetFirst() const = 0;

	virtual void Set(int index, T item) = 0;
	virtual void Append(T item) = 0;
	virtual void Prepend(T item) = 0;
	virtual void Insert(int index, T item) = 0;
	virtual void Remove(T item) = 0;
	virtual void RemoveAll(T item) = 0;
	virtual void RemoveAt(int index) = 0;
};

template <class T>

class DynamicArray
{
private:
	T* items;
	int size;

public:
	DynamicArray(T* items, const int size) {
		if (size < 0)
            throw std::exception("INVALID INPUT: size < 0");
		this->size = size;
		this->items = new T[size];
		for (int i = 0; i < size; i++) {
			this->items[i] = *(items + i);
		}
	}

	DynamicArray(const DynamicArray<T> &array) {
		this->size = array.GetSize();
		this->items = new T[this->size];
		for (int i = 0; i < this->size; i++) {
			this->Set(i, array.Get(i));
		}

	}

	DynamicArray(const int size) {
		if (size < 0)
            throw std::exception("INVALID INPUT: size < 0");
		this->items = new T[size];
		this->size = size;
	}

	int GetSize() {
		return this->size;
	}

	T Get(int index) {
		if (index < 0 || index >= this->size)
            throw std::exception("INDEX ERROR: Index out of range");
		return this->items[index];
	}

	T GetFirst() {
		return Get(0);
	}

	T GetLast() {
		return this->Get(this->GetSize() - 1);
	}

	void Set(int index, const T value) {
		if (index < 0 || index >= this->size)
            throw std::exception("IDNEX ERROR: Index out of range");
		this->items[index] = value;
	}

	~DynamicArray() {
		delete[] items;
	};
};



template <class T>

class LinkedList
{
private:
    template <class T>
	class Node {
	public:
        T item;
		Node* pnext;

        Node(T item = T(), Node* pnext = nullptr) {
			this->item = item;
			this->pnext = pnext;
		}
	};
	Node<T>* head;
	int size;
public:
	LinkedList() {
		this->size = 0;
		head = nullptr;
	};

	LinkedList(LinkedList<T>& list) {
		this->head = nullptr;
		this->size = list.Getsize();
		for (int i = 0; i < list.GetSize(); i++)
		{
			this->Prepend(list.Get(i));
		}
	};

	LinkedList(T* items, int size) {
		if (size < 0)
            throw std::exception("INVALID INPUT: Size < 0");
		this->head = nullptr;
		T* ptemp;
		this->size = size;
		for (int i = 0; i < size; i++)
		{
			ptemp = &items[i];
			if (head == nullptr)
			{
				head = new Node<T>(*ptemp);
			}
			else
			{
				Node<T>* temp = head;
				while (temp->pnext != nullptr)
				{
					temp = temp->pnext;
				}
				temp->pnext = new Node<T>(*ptemp);
			}
		}
	};

	int GetSize() {
		return this->size;
	}

	T Get(int index) {
		if (index < 0 || index >= this->size)
            throw std::exception("INDEX ERROR: Index out of range");

        Node<T>* temp;
        temp = this->head;
		for (int i = 0; i < index; i++) {
			temp = temp->pnext;
		}
		return temp->item;

	};

	T GetFirst() {
		return Get(0);
	};

	T GetLast() {
		return Get(this->size - 1);
	};

    void Set(int index, T item) {
        if (index < 0 || index >= this->size)
            throw std::exception("INDEX ERROR: Index out of range");

        Node<T>* temp;
        temp = this->head;
        for (int i = 0; i < index; i++) {
            temp = temp->pnext;
        }
        temp->item = item;
    };

	void Append(T item) {
		this->head = new Node<T>(item, this->head);
		++this->size;
	};

	void Prepend(T item) {
		if (head == nullptr)
			this->head = new Node<T>(item);
		else {
			Node<T>* temp;
			temp = this->head;
			while (temp->pnext != nullptr) {
				temp = temp->pnext;
			}
			temp->pnext = new Node<T>(item);
		}
		++this->size;
	};

	void InsertAt(T item, int index) {
		if (index < 0 || index >= this->size)
            throw std::exception("INDEX ERROR: Index out of range");
		if (index == 0)
			Append(item);
		else {
			Node<T>* temp;
			temp = this->head;
			for (int i = 0; i < index - 1; i++) {
				temp = temp->pnext;
			}
			Node<T>* newN = new Node<T>(item, temp->pnext);
			temp->pnext = newN;
		}
	};

	void fPop() {
		if (this->head == nullptr) {
            throw std::exception("INDEX ERROR: Empty list");
		}
		Node<T>* temp;
		temp = this->head;
		this->head = this->head->pnext;
		delete temp;
		--this->size;
	};

	void RemoveAt(int index) {
		if (index < 0 || index >= this->size)
            throw std::exception("INDEX ERROR: Index out of range");
		if (index == 0) {
			fPop();
		}
		else {
			Node<T>* temp;
			Node<T>* del;
			temp = this->head;
			for (int i = 0; i < index; i++) {
				temp = temp->pnext;
			}
			del = temp->pnext;
			temp->pnext = del->pnext;
			delete del;
			--this->size;
		}
	};

	LinkedList<T>* GetSubList(int start, int end) {
		if (start < 0 || start >= this->size || end < 0 || end >= this->size || end < start)
            throw std::exception("INDEX ERROR: Index out of range");
		T* temp = new T[end - start + 1];
		LinkedList<T>* tempList;
		tempList = new LinkedList<T>();
		for (int i = 0; i < end - start + 1; i++) {
			temp[i] = this->Get(i + start);
		}
		for (int i = 0; i < end - start + 1; i++) {
			tempList->Prepend(temp[i]);
		}
		delete[] temp;
		return tempList;
	};

	~LinkedList() {
		while (this->size > 0)
			fPop();
	};

	T& operator [] (const int index) {
		if (index < 0 || index >= this->size)
            throw std::exception("INDEX ERROR: Index out of range");
		Node<T>* temp;
		temp = this->head;
		int temp_i = 0;
		while (temp != nullptr) {
			if (temp_i == index) {
				return temp->item;
			}
			temp = temp->pnext;
			++temp_i;
		}
	};

};




template <class T>

class ArraySequence : public Sequence<T> {
private:
	DynamicArray<T>* items;
	int size;
public:
	ArraySequence(int size) {
		int current_size;
		if (size < 0) {
            cout << "WARNING!!! INPUTED SIZE < 0. IT WAS SETTED TO 1" << std::endl;
			current_size = 1;
		}
		else
			current_size = size;
		this->items = new DynamicArray<T>(current_size);
		this->size = size;
		for (int i = 0; i < current_size; i++) {
			this->items->Set(i, { 0 });
		}
	};

	ArraySequence(int size, DynamicArray<T>* items) {
		this->size = size;
		this->items = new DynamicArray<T>(size);
		for (int i = 0; i < size; i++) {
			this->items->Set(i, items->Get(i));
		}
	};

	ArraySequence(const ArraySequence<T>& tocopy) {
		this->size = tocopy.size;
		this->items = new DynamicArray(tocopy.items);
	};

	virtual int GetSize() const override {
		return this->items->GetSize();
	};

	virtual T Get(const int index) const override {
		return this->items->Get(index);
	};

	virtual T GetLast() const override {
		return this->items->GetLast();
	};

	virtual T GetFirst() const override {
		return this->items->GetFirst();
	};

	void Set(int index, T item) override {
		this->items->Set(index, item);
	};

	virtual void Append(T item) override {
		DynamicArray<T>* temp = new DynamicArray<T>(this->GetSize() + 1);
		for (int i = 1; i < this->size + 1; i++) {
			temp->Set(i, this->items->Get(i - 1));
		}
		temp->Set(0, item);
		++this->size;
		delete[] this->items;
		this->items = temp;
	};

	virtual void Prepend(T item) override {
		DynamicArray<T>* temp = new DynamicArray<T>(this->GetSize() + 1);
		for (int i = 0; i < this->size; i++) {
			temp->Set(i, this->items->Get(i));
		}
		temp->Set(this->GetSize(), item);
		++this->size;
		delete[] this->items;
		this->items = temp;
	};

	virtual void Insert(int index, T item) override {
		DynamicArray<T>* temp = new DynamicArray<T>(this->GetSize() + 1);
		for (int i = 0; i < index; i++) {
			temp->Set(i, this->items->Get(i));
		}
		temp->Set(index, item);
		for (int i = index + 1; i < this->GetSize() + 1; i++) {
			temp->Set(i, this->items->Get(i - 1));
		}
		++this->size;
		delete[] this->items;
		this->items = temp;
	};

	virtual void RemoveAt(int index) override {
		if (index < 0 || index >= this->size)
			throw std::exception("INDEX ERROR: Index out of range");
		DynamicArray<T>* temp;
		temp = new DynamicArray<T>(this->size - 1);
		for (int i = 0; i < index; i++) {
			temp->Set(i, this->items->Get(i));
		}
		for (int i = index + 1; i < this->size; i++) {
			temp->Set(i, this->items->Get(i));
		}
		delete items;
		--this->size;
		this->items = temp;
		delete[] temp;
	};

	virtual void Remove(T item) override {
		for (int i = 0; i < this->size; i++) {
			if (this->items->Get(i) == item) {
				RemoveAt(i);
				break;
			}
		}
	};

	virtual void RemoveAll(T item) override {
		int tempsize = this->size;
		for (int i = 0; i < tempsize; i++) {
			if (this->items->Get(i) == item) {
				RemoveAt(i);
				tempsize--;
				i--;
			}
		}
	};

    virtual Sequence<T>* Copy() override {
		ArraySequence<T>* copy;
		copy = new ArraySequence<T>(this->items->GetSize(), this->items);
		return copy;
	};

    virtual Sequence<T>* GetSubSequence(int start, int end) override {
		if (start < 0 || start >= this->size || end < 0 || end >= this->size)
			throw std::exception("INDEX ERROR: Index out of range");
		ArraySequence<T>* subseq;
		subseq = new ArraySequence(end - start + 1);
		int previndex = 0;
		for (int i = start; i < end; i++) {
			subseq->items->Set(previndex, this->items->Get(i));
			++previndex;
		}
		return subseq;
	};

	virtual Sequence<T>* Concat(Sequence<T>* toConcat) override {
		ArraySequence<T>* conc;
		conc = new ArraySequence<T>(this->size + toConcat->GetSize());
		for (int i = 0; i < this->size; i++) {
			conc->items->Set(i, this->items->Get(i));
		}
		for (int i = 0; i < toConcat->GetSize(); i++) {
			conc->items->Set(this->size + i, toConcat->Get(i));
		}
		return conc;
	};
};




template <class T>

class ListSequence : public Sequence<T> {
private:
	LinkedList<T>* items;
	int size;
public:
	ListSequence() {
		this->items = new LinkedList<T>();
		this->size = 0;
	};

	ListSequence(LinkedList<T>* items, int size) {
		this->size = size;
		this->items = new LinkedList<T>();
		for (int i = 0; i < size; i++) {
			this->Prepend(items->Get(i));
		}
	};

	ListSequence(T* items, int count) {
		this->items = new LinkedList<T>(items, count);
	};

	ListSequence(const ListSequence<T>& list) {
		this->size = list.size;
		this->items = new LinkedList<T>(list.GetSize());
		for (int i = 0; i < list.GetSize(); i++) {
			this->Prepend(list.Get(i));
		}
	};

	virtual int GetSize() const override {
		return this->items->GetSize();
	};

	virtual T Get(const int index) const override {
		if (index < 0 || index > this->size)
			throw std::exception("INDEX ERROR: Index out of range");
		return this->items->Get(index);
	};

	virtual T GetLast() const override {
		return this->items->GetLast();
	};

	virtual T GetFirst() const override {
		return this->items->GetFirst();
	};

	virtual void Set(int index, T item) override {
		this->items->Set(index, item);
	}

	virtual void Append(T item) override {
		this->items->Append(item);
		++this->size;
	};

	virtual void Prepend(T item) override {
		this->items->Prepend(item);
		++this->size;
	};

	virtual void Insert(int index, T item) override {
		this->items->InsertAt(item, index);
		++this->size;
	};

	virtual void RemoveAt(int index) override {
		if (index < 0 || index >= this->size)
			throw std::exception("INDEX ERROR: Index out of range");
		this->items->RemoveAt(index);
		--this->size;
	};

	virtual void Remove(T item) override {
		for (int i = 0; i < this->size; i++) {
			if (this->items->Get(i) == item) {
				this->items->RemoveAt(i);
				break;
			}
		}
		--this->size;
	};

	virtual void RemoveAll(T item) override {
		for (int i = 0; i < this->size; i++) {
			if (this->items->Get(i) == item) {
				RemoveAt(i);
				i--;
			}
		}
	};

	virtual Sequence<T>* Concat(Sequence<T>* toConcat) override {
		ListSequence<T>* tempList;
		tempList = new ListSequence<T>();
		T* temp;
		temp = new T[this->GetSize() + toConcat->GetSize()];
		for (int i = 0; i < this->GetSize(); i++) {
			temp[i] = this->Get(i);
		}
		for (int i = 0; i < toConcat->GetSize(); i++) {
			temp[i + this->GetSize()] = toConcat->Get(i);
		}
		for (int i = 0; i < this->GetSize() + toConcat->GetSize(); i++) {
			tempList->Prepend(temp[i]);
		}
		return tempList;
	};

	virtual Sequence<T>* GetSubSequence(int start, int end) override {
		if (start < 0 || start >= this->size || end < 0 || end >= this->size || end < start)
			throw std::exception("INDEX ERROR: Index out of range");
		ListSequence<T>* newList;
		newList = new ListSequence();
		newList->items = this->items->GetSubList(start, end);
		newList->size = newList->GetSize();
		this->size = newList->GetSize();
		return newList;
	};

	virtual Sequence<T>* Copy() override {
		ListSequence<T>* copy;
		copy = new ListSequence<T>();
		for (int i = 0; i < this->size; i++) {
			copy->items->Prepend(this->Get(i));
		}
		return copy;
	};


	~ListSequence() {
		delete this->items;
	};
};




template <class T>
class ISorter {
public:

	virtual void Sort(Sequence<T>* input, bool(*comp)(T, T)) = 0;

protected:
	void Swap(Sequence<T>* seq, int index1, int index2)
	{
		T item = seq->Get(index1);
		seq->Set(index1, seq->Get(index2));
		seq->Set(index2, item);
	}
};


template <class T>
class bubbleSorter : ISorter<T>
{
public:
    long long iterations = 0;
    long long comparisons = 0;

	void Sort(Sequence<T>* arr, bool(*comp)(T, T)) override {

		for (int i = 0; i < arr->GetSize(); i++) {
			for (int j = 0; j < arr->GetSize() - i - 1; j++) {
				if (comp(arr->Get(j), arr->Get(j + 1))) {

					this->Swap(arr, j, j + 1);
					++iterations;

				}
				++comparisons;
			}
		}
	}
};


template <class T>
class quickSorter : ISorter<T>
{
public:
    long long iterations;
    long long comparisons = 0;

	void Sort(Sequence<T>* arr, bool(*comp)(T, T)) override {
		quickSort(arr, comp, 0, arr->GetSize() - 1);
	}

	void quickSort(Sequence<T>* arr, bool(*comp)(T, T), int left, int right) {

		int i = left, j = right;

		T middle = arr->Get((left + right) / 2);

		while (i <= j) {
			while (!(comp(arr->Get(i), middle)) && !(arr->Get(i) == middle)) {
				comparisons++;
				i++;
			}
			while ((comp(arr->Get(j), middle))) {
				comparisons++;
				j--;
			}
			if (i <= j) {

				this->Swap(arr, i, j);
				iterations++;

				i++;
				j--;
			}
		};

		if (left < j)
			quickSort(arr, comp, left, j);
		if (i < right)
			quickSort(arr, comp, i, right);

	}
};


template <class T>
class insertSorter : ISorter<T>
{
public:
    long long iterations = 0;
    long long comparisons = 0;

	void Sort(Sequence<T>* arr, bool(*comp)(T, T)) override {

		T temp;

		for (int i = 0; i < arr->GetSize() - 1; i++)
		{
			int key = i + 1;
			temp = arr->Get(key);
			for (int j = i + 1; j > 0; j--)
			{
				++comparisons;
				if (!(comp(temp, arr->Get(j - 1))) && !(temp == arr->Get(j - 1)))
				{
					arr->Set(j, arr->Get(j - 1));
					key = j - 1;
					++iterations;
				}
			}
			arr->Set(key, temp);
		}
	}
};


template <class T>
class selectSorter : ISorter<T>
{
public:
    long long iterations = 0;
    long long comparisons = 0;

	void Sort(Sequence<T>* arr, bool(*comp)(T, T)) override {

		for (int startIndex = 0; startIndex < arr->GetSize(); ++startIndex) {

			int smallestIndex = startIndex;

			for (int currentIndex = startIndex + 1; currentIndex < arr->GetSize(); ++currentIndex) {

				if (!(comp(arr->Get(currentIndex), arr->Get(smallestIndex))) && !(arr->Get(currentIndex) == arr->Get(smallestIndex))) {
					++comparisons;
					smallestIndex = currentIndex;
				}
			}

			this->Swap(arr, startIndex, smallestIndex);
			++iterations;
		}
	}
};


template <class T>
class shellSorter : ISorter<T>
{
public:
    long long iterations = 0;
    long long comparisons = 0;

	void Sort(Sequence<T>* arr, bool(*comp)(T, T)) override {

		int step, i, j;

		for (step = arr->GetSize() / 2; step > 0; step /= 2)
			for (i = step; i < arr->GetSize(); i++) {
				++comparisons;
				for (j = i - step; j >= 0 && (comp(arr->Get(j), arr->Get(j + step))); j -= step, ++comparisons)
				{

					this->Swap(arr, j, j + step);
					++iterations;

				}
			}
	}
};


template <class T>
void shuffle(Sequence<T>* arr) {

	srand(time(NULL));

	for (int i = 0; i < arr->GetSize(); ++i) {
		T tmp = arr->Get(i);
		int r = rand() % arr->GetSize();
		arr->Set(i, arr->Get(r));
		arr->Set(r, tmp);
	}
};




class Timer {
private:

	std::chrono::steady_clock::time_point startTime;
	std::chrono::steady_clock::time_point endTime;

public:

	Timer() {
		startTime = chrono::high_resolution_clock::now();
	}

	double Time() {
		endTime = chrono::high_resolution_clock::now();
		chrono::duration<double> duration = endTime - startTime;
		return duration.count();
	}

	~Timer() {}

};



template <class T>
bool bigger(T first, T second) {
	return first > second;
}

template <class T>
bool low_r(T first, T second) {
	return first < second;
}
