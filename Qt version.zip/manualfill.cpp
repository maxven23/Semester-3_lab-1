#include "manualfill.h"
#include "ui_manualfill.h"

ManualFill::ManualFill(QWidget *parent, int SIZE, QString TYPE, Sequence<int>* SEQ) :
    QDialog(parent),
    ui(new Ui::ManualFill)
{
    Size = SIZE;
    seq = SEQ;
    Type = TYPE;
    ui->setupUi(this);

    if (TYPE == "Array")
        for (int i = 0; i < Size; i++) {

        }

    else if (TYPE == "List")
        for (int i = 0; i < Size; i++) {

        }


}

ManualFill::~ManualFill()
{
    delete ui;
}

void ManualFill::on_pushButton_clicked()
{
    int currentItem = ui->textEdit->text().toInt();
    ui->textEdit->setText("");
    if (Type == "Array")
        if (currentIndex < Size) {
            seq->Set(currentIndex, currentItem);
            ++currentIndex;
            QString current = QString::number(currentIndex);
            QString set = "Input #" + current + " element";
            ui->labelElem->setText(set);
        }
        else {
            hide();
            sortMenu = new SortMenu(this, seq);
            sortMenu->show();
        }
    else if (Type == "List") {
        if (currentIndex < Size) {
            seq->Append(currentItem);
            ++currentIndex;
            QString current = QString::number(currentIndex);
            QString set = "Input #" + current + " element";
            ui->labelElem->setText(set);
        }
        else {
            hide();
            sortMenu = new SortMenu(this, seq);
            sortMenu->show();
        }
    }
}
