#ifndef TYPEMENU_H
#define TYPEMENU_H

#include <QDialog>
#include "fillmenu.h"
#include "FullCode.h"

namespace Ui {
class TypeMenu;
}

class TypeMenu : public QDialog
{
    Q_OBJECT

public:
    explicit TypeMenu(QWidget *parent = nullptr, int SIZE = 1);
    ~TypeMenu();

private slots:
    void on_backBurron2_clicked();

    void on_confirmButton2_clicked();

private:
    int Size;
    Sequence<int>* seq;
    Ui::TypeMenu *ui;
    fillMenu *fillM;
};

#endif // TYPEMENU_H
