#ifndef FILLMENU_H
#define FILLMENU_H

#include <QDialog>
#include "sortmenu.h"
#include "manualfill.h"
#include "randomfill.h"

namespace Ui {
class fillMenu;
}

class fillMenu : public QDialog
{
    Q_OBJECT

public:
    explicit fillMenu(QWidget *parent = nullptr, int SIZE = 1, QString Type = "Array", Sequence<int>* Seq = nullptr);
    ~fillMenu();

private slots:
    void on_backButton3_clicked();

    void on_randomButton_clicked();

    void on_manualButton_clicked();

private:
    int Size;
    QString Type;
    Sequence<int>* seq;
    Ui::fillMenu *ui;
    RandomFill *randomFill;
    ManualFill *manualFill;
    SortMenu *sortMenu;
};

#endif // FILLMENU_H
