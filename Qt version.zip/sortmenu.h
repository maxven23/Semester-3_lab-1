#ifndef SORTMENU_H
#define SORTMENU_H

#include "FullCode.h"
#include "sort.h"
#include <QDialog>

namespace Ui {
class SortMenu;
}

class SortMenu : public QDialog
{
    Q_OBJECT

public:
    explicit SortMenu(QWidget *parent = nullptr, Sequence<int>* Seq = nullptr);
    ~SortMenu();

private slots:
    void on_backButton4_clicked();

    void on_bubbleButton_clicked();

    void on_insertButton_clicked();

    void on_selectButton_clicked();

    void on_shellButton_clicked();

    void on_quickButton_clicked();

    void on_shuffleButton_clicked();

private:
    Sequence<int>* seq;
    Sort *sort;
    Ui::SortMenu *ui;
};

#endif // SORTMENU_H
