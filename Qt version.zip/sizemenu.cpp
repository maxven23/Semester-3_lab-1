#include "sizemenu.h"
#include "ui_sizemenu.h"

SizeMenu::SizeMenu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SizeMenu)
{
    ui->setupUi(this);
}

SizeMenu::~SizeMenu()
{
    delete ui;
}

void SizeMenu::on_pushButton_2_clicked()
{
    auto p = parentWidget();
    p->show();
    close();
}

void SizeMenu::on_confirmBurron1_clicked()
{
    int SIZE = ui->spinBox->value();
    hide();
    typeMenu = new TypeMenu(this, SIZE);
    typeMenu->show();
}
