#include "fillmenu.h"
#include "ui_fillmenu.h"

fillMenu::fillMenu(QWidget *parent, int SIZE, QString TYPE, Sequence<int>* Seq) :
    QDialog(parent),
    ui(new Ui::fillMenu)
{
    seq = Seq;
    Type = TYPE;
    Size = SIZE;
    ui->setupUi(this);
}

fillMenu::~fillMenu()
{
    delete ui;
}

void fillMenu::on_backButton3_clicked()
{
    auto p = parentWidget();
    p->show();
    close();
}

void fillMenu::on_randomButton_clicked()
{
    hide();
    randomFill = new RandomFill(nullptr, Size, Type, seq);
    delete randomFill;
    sortMenu = new SortMenu(this, seq);
    sortMenu->show();
}

void fillMenu::on_manualButton_clicked()
{
    hide();
    manualFill = new ManualFill(nullptr, Size, Type, seq);
    manualFill->show();
}
