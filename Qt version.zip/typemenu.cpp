#include "typemenu.h"
#include "ui_typemenu.h"

TypeMenu::TypeMenu(QWidget *parent, int SIZE) :
    QDialog(parent),
    ui(new Ui::TypeMenu)
{
    Size = SIZE;
    ui->setupUi(this);
}

TypeMenu::~TypeMenu()
{
    delete ui;
}

void TypeMenu::on_backBurron2_clicked()
{
    auto p = parentWidget();
    p->show();
    close();
}

void TypeMenu::on_confirmButton2_clicked()
{
    if (ui->arrayRadioBut->isChecked()) {
        seq = new ArraySequence<int>(Size);

        fillM = new fillMenu(this, Size, "Array", seq);
        hide();
        fillM->show();
    }
    else if (ui->listRadioBut->isChecked()) {
        seq = new ListSequence<int>();

        fillM = new fillMenu(this, Size, "List", seq);
        hide();
        fillM->show();
    }
}
