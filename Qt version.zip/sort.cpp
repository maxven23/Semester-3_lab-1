#include "sort.h"
#include "ui_sort.h"

Sort::Sort(QWidget *parent, Sequence<int>* SEQ, QString STYPE) :
    QDialog(parent),
    ui(new Ui::Sort)
{
    seq = SEQ;
    SortType = STYPE;
    ui->setupUi(this);

    ui->sortLabel->setText(STYPE);

    if (seq->GetSize() < 101) {
        QString str = "[";
        for (int i = 0; i < seq->GetSize() - 1; i++) {
            str += QString::number(seq->Get(i));
            str += ",  ";
        }
        str += QString::number(seq->GetLast());
        str += "]";
        ui->seqLabel->setText(str);
    } else {
        QFont font = ui->seqLabel->font();
        font.setPixelSize(32);
        ui->seqLabel->setFont(font);
        ui->seqLabel->setText("Your Sequence is too big!");
    }
}

Sort::~Sort()
{
    delete ui;
}

void Sort::on_backButtonSort_clicked()
{
    auto p = parentWidget();
    p->show();
    close();
}

void Sort::on_ascButton_clicked()
{
    if (SortType == "Bubble Sort") {
        bubbleSorter<int>* sorter = new bubbleSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, bigger);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Insetrion Sort") {
        insertSorter<int>* sorter = new insertSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, bigger);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Selection Sort") {
        selectSorter<int>* sorter = new selectSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, bigger);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Shell Sort") {
        shellSorter<int>* sorter = new shellSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, bigger);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Quick Sort") {
        quickSorter<int>* sorter = new quickSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, bigger);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
}

void Sort::on_descButton_clicked()
{
    if (SortType == "Bubble Sort") {
        bubbleSorter<int>* sorter = new bubbleSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, low_r);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Insetrion Sort") {
        insertSorter<int>* sorter = new insertSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, low_r);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Selection Sort") {
        selectSorter<int>* sorter = new selectSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, low_r);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));

        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Shell Sort") {
        shellSorter<int>* sorter = new shellSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, low_r);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));
        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += " ,  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
    else if (SortType == "Quick Sort") {
        quickSorter<int>* sorter = new quickSorter<int>();
        Timer* timer = new Timer();
        sorter->Sort(seq, low_r);
        float time = timer->Time();
        ui->timeOutputLabel->setText(QString::number(time));
        ui->iterOutpurLabel->setText(QString::number(sorter->iterations));
        ui->compOutputLabel->setText(QString::number(sorter->comparisons));
        ui->elemOutputLabel->setText(QString::number(seq->GetSize()));
        if (seq->GetSize() < 101) {
            QString str = "[";
            for (int i = 0; i < seq->GetSize() - 1; i++) {
                str += QString::number(seq->Get(i));
                str += ",  ";
            }
            str += QString::number(seq->GetLast());
            str += "]";
            ui->outputLabel->setText(str);
        } else {
            QFont font = ui->outputLabel->font();
            font.setPixelSize(32);
            ui->outputLabel->setFont(font);
            ui->outputLabel->setText("Your Sequence is too big!");
        }
    }
}
