#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#pragma once
#include "FullCode.h"
#include <QDialog>

template <class T>
void FillArray(Sequence<T>* seq, QString FILL) {

    if (FILL == "Random") {
        for (int i = 0; i < seq->GetSize(); i++) {
            seq->Set(i, i); // seq->Set(i, rand_T())
        }
        shuffle(seq);
    }

    else if (FILL == "Manual") {
        //
    }
}

template <class T>
void FillList(Sequence<T>* seq, int SIZE, QString FILL) {

    if (FILL == "Random") {
        for (int i = 0; i < SIZE; i++) {
            seq->Prepend(i); // seq->Prepend(rand_T())
        }
        shuffle(seq);
    }

    else if (FILL == "Manual") {
        //
    }
}

#endif // FUNCTIONS_H
