#ifndef MANUALFILL_H
#define MANUALFILL_H

#include <QDialog>
#include "FullCode.h"
#include "sortmenu.h"

namespace Ui {
class ManualFill;
}

class ManualFill : public QDialog
{
    Q_OBJECT

public:
    explicit ManualFill(QWidget *parent = nullptr, int SIZE = 1, QString TYPE = "Array", Sequence<int>* SEQ = nullptr);
    ~ManualFill();

private slots:
    void on_pushButton_clicked();

private:
    int currentIndex = 1;
    int Size;
    QString Type;
    Sequence<int>* seq;
    Ui::ManualFill *ui;
    SortMenu *sortMenu;
};

#endif // MANUALFILL_H
